package com.example.koltsegszamlalo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.IOException;

public class HelloController {

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private Button registration_lbl;

    @FXML
    private Button login;

    @FXML
    private Label welcome;


    @FXML
    protected void onLoginButtonClick(ActionEvent actionEvent) throws  IOException {
        Alert succeedAlert = new Alert(Alert.AlertType.INFORMATION);;
        succeedAlert.setHeaderText("Login was successful.");
        succeedAlert.showAndWait();
        switchToMenu(actionEvent);
    }

    private Stage stage;
    private Scene scene;
    private Parent root;

@FXML
public void switchToMenu(ActionEvent event) throws IOException {
 Parent root = FXMLLoader.load(getClass().getResource("menu.fxml"));
 stage = (Stage)((Node)event.getSource()).getScene().getWindow();
 scene = new Scene(root);
 stage.setScene(scene);
 stage.show() ;
 welcome.setText("Welcome");

    }

}



/*
public class LoginController {



    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private Label registration_lbl;

    @FXML
    private Button login;

    @FXML
    public void init(){
        if(!profileHandler.checkProfiles()){
            login.setDisable(true);
        }
        else{
            login.setDisable(false);
        }
    }

    @FXML
    public void login(ActionEvent actionEvent) throws IOException {
        if(profileHandler.loginProfile(username.getText(), password.getText())){
            Logger.info(username.getText() + ": Login was successful.");
            Alert succeedAlert = new Alert(Alert.AlertType.INFORMATION);
            succeedAlert.setHeaderText("Login was successful.");
            succeedAlert.showAndWait();

            switchToMenu(actionEvent);
        }
        else{
            Logger.error(username.getText() + ": Failed to login ");

            Alert passwordAlert = new Alert(Alert.AlertType.WARNING);
            passwordAlert.setHeaderText("Bad Credentials");
            passwordAlert.setContentText("Invalid Username and/or Password");
            passwordAlert.showAndWait();
        }

    }

    public void registration(ActionEvent actionEvent) throws IOException {
        if(!login.isDisable())
        {
            registration_lbl.setVisible(true);
            login.setDisable(true);
        }
        else if(login.isDisable())
        {
            profileHandler.CreateProfile(username.getText(), password.getText());

            Logger.info(username.getText() + ": Registration was successful.");

            Alert succeedAlert = new Alert(Alert.AlertType.INFORMATION);
            succeedAlert.setHeaderText("Registration was successful.");
            succeedAlert.showAndWait();

            switchToMenu(actionEvent);
        }
    }

    public void switchToMenu(ActionEvent event) throws IOException {


    }
}
*/
